ARIN — African Research & Innovation Network
Website starter package

WHAT IS INCLUDED
- index.html: the website and research registration form
- style.css: responsive visual design for phone and computer
- app.js: menu behavior, character counters and basic form validation
- database-schema.sql: starter private-profile schema and row-level security policies for Supabase

IMPORTANT CURRENT LIMITATION
This is a frontend starter, not yet a live registration service. The form does not send or save data.
Do not collect real people's personal details until authentication, database writes, email verification,
server-side validation, anti-spam controls, backups and a privacy notice have been configured and tested.

SUGGESTED NEXT STEPS
1. Preview locally by opening index.html in a browser.
2. Create a Supabase project and review/run database-schema.sql in its SQL Editor.
3. Implement secure sign-up/login and server/database integration. Each account must only access its
   own private profile. Build a separate public directory that shows only fields users explicitly opt into.
4. Add an admin role using server-side authorization (never a public JavaScript password).
5. Publish the static frontend with a hosting provider such as Netlify or Vercel, and connect a custom
   domain after checking that the name/domain is available.
6. Test on a phone and desktop before inviting people.

BRAND
Working name: ARIN
Full name: African Research & Innovation Network
Focus: international collaboration, with special attention to African research and innovation.

FORM CONTENT
Personal details; education level; age; gender; email; phone; research field; research idea (max 10 lines);
expected benefit of participation (max 2 lines).

PRIVACY NOTE
The initial form requests personal information. Collect only what is necessary, explain why it is needed,
obtain informed consent, restrict access and publish a privacy policy before public launch. Consider making
full street address optional and allowing users to keep contact details private.
