-- ARIN starter schema for Supabase (PostgreSQL).
-- Review with a developer before production. Never put a service-role key in frontend code.

create extension if not exists pgcrypto;

create table if not exists public.member_profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null check (char_length(full_name) between 1 and 120),
  address text not null check (char_length(address) <= 200),
  education_level text not null check (education_level in ('PhD','MSc','BSc','Grade 12+','Grade 10+','Other')),
  age integer not null check (age between 18 and 120),
  gender text not null check (gender in ('M','F','Prefer not to say')),
  email text not null,
  phone text not null check (char_length(phone) <= 30),
  research_field text not null,
  research_idea text not null check (char_length(research_idea) <= 1200),
  benefit text not null check (char_length(benefit) <= 240),
  created_at timestamptz not null default now()
);

alter table public.member_profiles enable row level security;

-- Each signed-in member can read and update only their own private profile.
create policy "Members can read their own profile"
on public.member_profiles for select
to authenticated
using (auth.uid() = user_id);

create policy "Members can insert their own profile"
on public.member_profiles for insert
to authenticated
with check (auth.uid() = user_id);

create policy "Members can update their own profile"
on public.member_profiles for update
to authenticated
using (auth.uid() = user_id)
with check (auth.uid() = user_id);

-- Intentionally no public SELECT policy: names, addresses, emails, phones, age and
-- other submitted details must not become visible to all visitors.
-- Before launching, add a separate public researcher directory with explicit opt-in
-- and only fields each member agrees to display. Admin access should use a server-side
-- role/authorization design; do not make an admin password or service key public.
