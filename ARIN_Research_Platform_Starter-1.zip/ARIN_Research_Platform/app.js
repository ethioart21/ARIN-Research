// ARIN starter frontend.
// This demo validates the form in the browser only. It does NOT save registrations yet.
// Connect a secure backend/database before publishing the form for real users.
const menuToggle = document.getElementById("menuToggle");
const mainNav = document.getElementById("mainNav");
menuToggle?.addEventListener("click", () => {
  const open = mainNav.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(open));
});
mainNav?.querySelectorAll("a").forEach(link => link.addEventListener("click", () => {
  mainNav.classList.remove("open");
  menuToggle?.setAttribute("aria-expanded", "false");
}));

document.getElementById("year").textContent = new Date().getFullYear();

const researchIdea = document.getElementById("researchIdea");
const benefit = document.getElementById("benefit");
const ideaCounter = document.getElementById("ideaCounter");
const benefitCounter = document.getElementById("benefitCounter");
function updateCounter(field, counter, max) {
  counter.textContent = `${field.value.length} / ${max} characters`;
}
researchIdea.addEventListener("input", () => updateCounter(researchIdea, ideaCounter, 1200));
benefit.addEventListener("input", () => updateCounter(benefit, benefitCounter, 240));

function lineCount(value) {
  return value.split(/\r\n|\r|\n/).length;
}
function showStatus(message, type) {
  const status = document.getElementById("formStatus");
  status.textContent = message;
  status.className = `form-status ${type}`;
}
document.getElementById("registrationForm").addEventListener("submit", (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  if (!form.reportValidity()) return;
  if (lineCount(researchIdea.value) > 10) {
    researchIdea.focus();
    showStatus("Please shorten your research idea to 10 lines or fewer.", "error");
    return;
  }
  if (lineCount(benefit.value) > 2) {
    benefit.focus();
    showStatus("Please shorten the benefit statement to 2 lines or fewer.", "error");
    return;
  }
  showStatus("The form looks valid, but online registration is not active yet. A database and secure backend must be connected before real submissions can be accepted.", "error");
});

// NOTE: Do not store or publish private contact details in browser code or public repositories.
